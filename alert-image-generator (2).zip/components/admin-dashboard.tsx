"use client"

import type React from "react"

import { useState, useEffect, useCallback } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from "@/components/ui/dialog"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import {
  BarChart3,
  Users,
  Download,
  Trash2,
  Edit,
  Plus,
  AlertTriangle,
  TrendingUp,
  Activity,
  LogOut,
  Save,
  X,
  FileJson,
  FileUp,
  Search,
  RefreshCw,
} from "lucide-react"
import { toast } from "@/hooks/use-toast"

interface Template {
  id: string
  name: string
  type: string
  message: string
  targetArea: string
  backgroundColor: string
  textColor: string
  usage: number
  lastUsed: string
  status: "active" | "draft" | "archived"
  createdAt: string
  updatedAt: string
}

interface User {
  id: string
  name: string
  email: string
  role: "admin" | "editor" | "viewer"
  lastActive: string
  alertsCreated: number
  createdAt: string
  updatedAt: string
}

interface SystemSettings {
  systemName: string
  maxUsers: number
  storageLimit: number
  emailNotifications: string
  alertThreshold: number
  backupFrequency: string
  lastBackup: string | null
  updatedAt: string
}

interface SystemStats {
  totalTemplates: number
  activeTemplates: number
  totalUsers: number
  adminUsers: number
  totalUsage: number
  totalAlerts: number
}

const initialTemplates: Template[] = [
  {
    id: "1",
    name: "大雨特別警報テンプレート",
    type: "heavyRainSpecial",
    message: "命を守る行動を！",
    targetArea: "全国",
    backgroundColor: "#dc2626",
    textColor: "#ffffff",
    usage: 245,
    lastUsed: "2024-01-15",
    status: "active",
    createdAt: "2024-01-01",
    updatedAt: "2024-01-01",
  },
  {
    id: "2",
    name: "津波警報テンプレート",
    type: "tsunami",
    message: "直ちに高台へ避難を！",
    targetArea: "沿岸部",
    backgroundColor: "#0891b2",
    textColor: "#ffffff",
    usage: 89,
    lastUsed: "2024-01-10",
    status: "active",
    createdAt: "2024-01-02",
    updatedAt: "2024-01-02",
  },
]

const initialUsers: User[] = [
  {
    id: "1",
    name: "田中太郎",
    email: "tanaka@example.com",
    role: "admin",
    lastActive: "2024-01-15",
    alertsCreated: 45,
    createdAt: "2024-01-01",
    updatedAt: "2024-01-01",
  },
  {
    id: "2",
    name: "佐藤花子",
    email: "sato@example.com",
    role: "editor",
    lastActive: "2024-01-14",
    alertsCreated: 32,
    createdAt: "2024-01-02",
    updatedAt: "2024-01-02",
  },
]

const initialSettings: SystemSettings = {
  systemName: "警報画像作成システム",
  maxUsers: 100,
  storageLimit: 50,
  emailNotifications: "admin@example.com",
  alertThreshold: 1000,
  backupFrequency: "毎日",
  lastBackup: null,
  updatedAt: new Date().toISOString(),
}

interface AdminDashboardProps {
  onLogout: () => void
}

export default function AdminDashboard({ onLogout }: AdminDashboardProps) {
  const [templates, setTemplates] = useState<Template[]>([])
  const [users, setUsers] = useState<User[]>([])
  const [settings, setSettings] = useState<SystemSettings>(initialSettings)
  const [editingTemplate, setEditingTemplate] = useState<Template | null>(null)
  const [editingUser, setEditingUser] = useState<User | null>(null)
  const [isTemplateDialogOpen, setIsTemplateDialogOpen] = useState(false)
  const [isUserDialogOpen, setIsUserDialogOpen] = useState(false)
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null)
  const [deleteConfirmType, setDeleteConfirmType] = useState<"template" | "user" | null>(null)
  const [searchQuery, setSearchQuery] = useState("")
  const [isExporting, setIsExporting] = useState(false)
  const [isImporting, setIsImporting] = useState(false)
  const [stats, setStats] = useState<SystemStats>({
    totalTemplates: 0,
    activeTemplates: 0,
    totalUsers: 0,
    adminUsers: 0,
    totalUsage: 0,
    totalAlerts: 0,
  })

  // データの読み込み
  const loadData = useCallback(() => {
    try {
      const savedTemplates = localStorage.getItem("adminTemplates")
      const savedUsers = localStorage.getItem("adminUsers")
      const savedSettings = localStorage.getItem("adminSettings")

      if (savedTemplates) {
        setTemplates(JSON.parse(savedTemplates))
      } else {
        setTemplates(initialTemplates)
      }

      if (savedUsers) {
        setUsers(JSON.parse(savedUsers))
      } else {
        setUsers(initialUsers)
      }

      if (savedSettings) {
        setSettings(JSON.parse(savedSettings))
      }
    } catch (error) {
      console.error("データの読み込みに失敗しました", error)
      toast({
        title: "エラー",
        description: "データの読み込みに失敗しました",
        variant: "destructive",
      })
    }
  }, [])

  useEffect(() => {
    loadData()
  }, [loadData])

  // 統計情報の更新
  useEffect(() => {
    setStats({
      totalTemplates: templates.length,
      activeTemplates: templates.filter((t) => t.status === "active").length,
      totalUsers: users.length,
      adminUsers: users.filter((u) => u.role === "admin").length,
      totalUsage: templates.reduce((sum, t) => sum + t.usage, 0),
      totalAlerts: users.reduce((sum, u) => sum + u.alertsCreated, 0),
    })
  }, [templates, users])

  // データの保存
  const saveData = useCallback(() => {
    try {
      localStorage.setItem("adminTemplates", JSON.stringify(templates))
      localStorage.setItem("adminUsers", JSON.stringify(users))
      localStorage.setItem("adminSettings", JSON.stringify(settings))
    } catch (error) {
      console.error("データの保存に失敗しました", error)
      toast({
        title: "エラー",
        description: "データの保存に失敗しました",
        variant: "destructive",
      })
    }
  }, [templates, users, settings])

  useEffect(() => {
    saveData()
  }, [templates, users, settings, saveData])

  const handleLogout = () => {
    localStorage.removeItem("adminAuthenticated")
    localStorage.removeItem("adminLoginTime")
    toast({
      title: "ログアウトしました",
      description: "管理画面からログアウトしました",
    })
    onLogout()
  }

  // テンプレート関連の関数
  const handleSaveTemplate = (template: Omit<Template, "id" | "usage" | "lastUsed" | "createdAt" | "updatedAt">) => {
    try {
      const now = new Date().toISOString()

      if (editingTemplate) {
        // 編集
        setTemplates(
          templates.map((t) =>
            t.id === editingTemplate.id
              ? {
                  ...template,
                  id: editingTemplate.id,
                  usage: editingTemplate.usage,
                  lastUsed: editingTemplate.lastUsed,
                  createdAt: editingTemplate.createdAt,
                  updatedAt: now,
                }
              : t,
          ),
        )
        toast({
          title: "テンプレートを更新しました",
          description: `${template.name}を更新しました`,
        })
      } else {
        // 新規作成
        const newTemplate: Template = {
          ...template,
          id: Date.now().toString(),
          usage: 0,
          lastUsed: now.split("T")[0],
          createdAt: now,
          updatedAt: now,
        }
        setTemplates([...templates, newTemplate])
        toast({
          title: "テンプレートを作成しました",
          description: `${template.name}を作成しました`,
        })
      }
      setEditingTemplate(null)
      setIsTemplateDialogOpen(false)
    } catch (error) {
      console.error("テンプレートの保存に失敗しました", error)
      toast({
        title: "エラー",
        description: "テンプレートの保存に失敗しました",
        variant: "destructive",
      })
    }
  }

  const handleDeleteTemplate = (id: string) => {
    try {
      const template = templates.find((t) => t.id === id)
      if (!template) return

      setTemplates(templates.filter((t) => t.id !== id))
      toast({
        title: "テンプレートを削除しました",
        description: `${template.name}を削除しました`,
      })
    } catch (error) {
      console.error("テンプレートの削除に失敗しました", error)
      toast({
        title: "エラー",
        description: "テンプレートの削除に失敗しました",
        variant: "destructive",
      })
    }
  }

  // ユーザー関連の関数
  const handleSaveUser = (user: Omit<User, "id" | "lastActive" | "alertsCreated" | "createdAt" | "updatedAt">) => {
    try {
      const now = new Date().toISOString()

      if (editingUser) {
        // 編集
        setUsers(
          users.map((u) =>
            u.id === editingUser.id
              ? {
                  ...user,
                  id: editingUser.id,
                  lastActive: editingUser.lastActive,
                  alertsCreated: editingUser.alertsCreated,
                  createdAt: editingUser.createdAt,
                  updatedAt: now,
                }
              : u,
          ),
        )
        toast({
          title: "ユーザーを更新しました",
          description: `${user.name}を更新しました`,
        })
      } else {
        // 新規作成
        const newUser: User = {
          ...user,
          id: Date.now().toString(),
          lastActive: now.split("T")[0],
          alertsCreated: 0,
          createdAt: now,
          updatedAt: now,
        }
        setUsers([...users, newUser])
        toast({
          title: "ユーザーを作成しました",
          description: `${user.name}を作成しました`,
        })
      }
      setEditingUser(null)
      setIsUserDialogOpen(false)
    } catch (error) {
      console.error("ユーザーの保存に失敗しました", error)
      toast({
        title: "エラー",
        description: "ユーザーの保存に失敗しました",
        variant: "destructive",
      })
    }
  }

  const handleDeleteUser = (id: string) => {
    try {
      const user = users.find((u) => u.id === id)
      if (!user) return

      setUsers(users.filter((u) => u.id !== id))
      toast({
        title: "ユーザーを削除しました",
        description: `${user.name}を削除しました`,
      })
    } catch (error) {
      console.error("ユーザーの削除に失敗しました", error)
      toast({
        title: "エラー",
        description: "ユーザーの削除に失敗しました",
        variant: "destructive",
      })
    }
  }

  // 設定の保存
  const handleSaveSettings = () => {
    try {
      const now = new Date().toISOString()
      setSettings({
        ...settings,
        updatedAt: now,
      })
      toast({
        title: "設定を保存しました",
        description: "システム設定が更新されました",
      })
    } catch (error) {
      console.error("設定の保存に失敗しました", error)
      toast({
        title: "エラー",
        description: "設定の保存に失敗しました",
        variant: "destructive",
      })
    }
  }

  // バックアップ作成
  const handleCreateBackup = () => {
    try {
      const now = new Date().toISOString()
      setSettings({
        ...settings,
        lastBackup: now,
        updatedAt: now,
      })
      toast({
        title: "バックアップを作成しました",
        description: "システムデータのバックアップが完了しました",
      })
    } catch (error) {
      console.error("バックアップの作成に失敗しました", error)
      toast({
        title: "エラー",
        description: "バックアップの作成に失敗しました",
        variant: "destructive",
      })
    }
  }

  // データエクスポート
  const handleExportData = () => {
    try {
      setIsExporting(true)

      const exportData = {
        templates,
        users,
        settings,
        exportDate: new Date().toISOString(),
      }

      const dataStr = JSON.stringify(exportData, null, 2)
      const dataUri = `data:application/json;charset=utf-8,${encodeURIComponent(dataStr)}`

      const exportFileName = `alert-system-export-${new Date().toISOString().split("T")[0]}.json`

      const linkElement = document.createElement("a")
      linkElement.setAttribute("href", dataUri)
      linkElement.setAttribute("download", exportFileName)
      linkElement.click()

      toast({
        title: "エクスポート完了",
        description: "システムデータのエクスポートが完了しました",
      })
    } catch (error) {
      console.error("データのエクスポートに失敗しました", error)
      toast({
        title: "エラー",
        description: "データのエクスポートに失敗しました",
        variant: "destructive",
      })
    } finally {
      setIsExporting(false)
    }
  }

  // データインポート
  const handleImportData = (event: React.ChangeEvent<HTMLInputElement>) => {
    try {
      setIsImporting(true)

      const file = event.target.files?.[0]
      if (!file) {
        toast({
          title: "エラー",
          description: "ファイルが選択されていません",
          variant: "destructive",
        })
        return
      }

      const reader = new FileReader()
      reader.onload = (e) => {
        try {
          const content = e.target?.result as string
          const importedData = JSON.parse(content)

          if (importedData.templates && Array.isArray(importedData.templates)) {
            setTemplates(importedData.templates)
          }

          if (importedData.users && Array.isArray(importedData.users)) {
            setUsers(importedData.users)
          }

          if (importedData.settings) {
            setSettings({
              ...importedData.settings,
              updatedAt: new Date().toISOString(),
            })
          }

          toast({
            title: "インポート完了",
            description: "システムデータのインポートが完了しました",
          })
        } catch (error) {
          console.error("インポートデータの解析に失敗しました", error)
          toast({
            title: "エラー",
            description: "インポートデータの形式が正しくありません",
            variant: "destructive",
          })
        }
      }

      reader.readAsText(file)
    } catch (error) {
      console.error("データのインポートに失敗しました", error)
      toast({
        title: "エラー",
        description: "データのインポートに失敗しました",
        variant: "destructive",
      })
    } finally {
      setIsImporting(false)
      // ファイル選択をリセット
      const fileInput = document.getElementById("import-file") as HTMLInputElement
      if (fileInput) fileInput.value = ""
    }
  }

  // 検索フィルター
  const filteredTemplates = templates.filter(
    (template) =>
      template.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      template.type.toLowerCase().includes(searchQuery.toLowerCase()) ||
      template.message.toLowerCase().includes(searchQuery.toLowerCase()) ||
      template.targetArea.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  const filteredUsers = users.filter(
    (user) =>
      user.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      user.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
      user.role.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  const getStatusBadge = (status: Template["status"]) => {
    const variants = {
      active: "default",
      draft: "secondary",
      archived: "outline",
    } as const

    return <Badge variant={variants[status]}>{status}</Badge>
  }

  const getRoleBadge = (role: User["role"]) => {
    const variants = {
      admin: "destructive",
      editor: "default",
      viewer: "secondary",
    } as const

    return <Badge variant={variants[role]}>{role}</Badge>
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50">
      <div className="container mx-auto p-6 space-y-8">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h1 className="text-4xl font-bold bg-gradient-to-r from-slate-900 to-slate-600 bg-clip-text text-transparent">
              管理ダッシュボード
            </h1>
            <p className="text-slate-600 mt-2">警報画像作成システムの統合管理</p>
          </div>
          <div className="flex flex-wrap gap-3">
            <Button variant="outline" className="shadow-sm" onClick={handleExportData} disabled={isExporting}>
              <FileJson className="w-4 h-4 mr-2" />
              {isExporting ? "エクスポート中..." : "エクスポート"}
            </Button>
            <div className="relative">
              <input
                type="file"
                id="import-file"
                accept=".json"
                onChange={handleImportData}
                className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                disabled={isImporting}
              />
              <Button variant="outline" className="shadow-sm" disabled={isImporting}>
                <FileUp className="w-4 h-4 mr-2" />
                {isImporting ? "インポート中..." : "インポート"}
              </Button>
            </div>
            <Button
              onClick={handleLogout}
              variant="outline"
              className="shadow-sm text-red-600 hover:text-red-700 hover:bg-red-50"
            >
              <LogOut className="w-4 h-4 mr-2" />
              ログアウト
            </Button>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <Card className="border-0 shadow-lg bg-gradient-to-br from-blue-500 to-blue-600 text-white">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-blue-100 text-sm font-medium">総テンプレート数</p>
                  <p className="text-3xl font-bold">{stats.totalTemplates}</p>
                </div>
                <AlertTriangle className="w-8 h-8 text-blue-200" />
              </div>
              <div className="flex items-center mt-4 text-blue-100">
                <TrendingUp className="w-4 h-4 mr-1" />
                <span className="text-sm">アクティブ: {stats.activeTemplates}</span>
              </div>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-lg bg-gradient-to-br from-emerald-500 to-emerald-600 text-white">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-emerald-100 text-sm font-medium">登録ユーザー数</p>
                  <p className="text-3xl font-bold">{stats.totalUsers}</p>
                </div>
                <Users className="w-8 h-8 text-emerald-200" />
              </div>
              <div className="flex items-center mt-4 text-emerald-100">
                <Activity className="w-4 h-4 mr-1" />
                <span className="text-sm">管理者: {stats.adminUsers}</span>
              </div>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-lg bg-gradient-to-br from-purple-500 to-purple-600 text-white">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-purple-100 text-sm font-medium">総使用回数</p>
                  <p className="text-3xl font-bold">{stats.totalUsage.toLocaleString()}</p>
                </div>
                <BarChart3 className="w-8 h-8 text-purple-200" />
              </div>
              <div className="flex items-center mt-4 text-purple-100">
                <TrendingUp className="w-4 h-4 mr-1" />
                <span className="text-sm">今月の使用</span>
              </div>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-lg bg-gradient-to-br from-orange-500 to-orange-600 text-white">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-orange-100 text-sm font-medium">作成画像数</p>
                  <p className="text-3xl font-bold">{stats.totalAlerts.toLocaleString()}</p>
                </div>
                <Download className="w-8 h-8 text-orange-200" />
              </div>
              <div className="flex items-center mt-4 text-orange-100">
                <TrendingUp className="w-4 h-4 mr-1" />
                <span className="text-sm">総作成数</span>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* 検索バー */}
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400" />
          <Input
            placeholder="テンプレート、ユーザーを検索..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10 pr-10 border-slate-200 focus:border-blue-500 focus:ring-blue-500"
          />
          {searchQuery && (
            <Button
              variant="ghost"
              size="sm"
              className="absolute right-0 top-0 h-full px-3 py-2 hover:bg-transparent"
              onClick={() => setSearchQuery("")}
            >
              <X className="w-4 h-4" />
            </Button>
          )}
        </div>

        {/* Main Content */}
        <Tabs defaultValue="templates" className="space-y-6">
          <TabsList className="grid w-full grid-cols-3 bg-white shadow-sm border-0">
            <TabsTrigger
              value="templates"
              className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-blue-500 data-[state=active]:to-indigo-500 data-[state=active]:text-white"
            >
              テンプレート管理
            </TabsTrigger>
            <TabsTrigger
              value="users"
              className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-blue-500 data-[state=active]:to-indigo-500 data-[state=active]:text-white"
            >
              ユーザー管理
            </TabsTrigger>
            <TabsTrigger
              value="settings"
              className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-blue-500 data-[state=active]:to-indigo-500 data-[state=active]:text-white"
            >
              システム設定
            </TabsTrigger>
          </TabsList>

          <TabsContent value="templates" className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-bold text-slate-800">テンプレート管理</h2>
              <Dialog open={isTemplateDialogOpen} onOpenChange={setIsTemplateDialogOpen}>
                <DialogTrigger asChild>
                  <Button
                    onClick={() => {
                      setEditingTemplate(null)
                      setIsTemplateDialogOpen(true)
                    }}
                    className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700"
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    新規テンプレート
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-2xl">
                  <DialogHeader>
                    <DialogTitle>{editingTemplate ? "テンプレート編集" : "新規テンプレート作成"}</DialogTitle>
                    <DialogDescription>テンプレートの詳細情報を入力してください</DialogDescription>
                  </DialogHeader>
                  <TemplateForm
                    template={editingTemplate}
                    onSave={handleSaveTemplate}
                    onCancel={() => setIsTemplateDialogOpen(false)}
                  />
                </DialogContent>
              </Dialog>
            </div>

            <Card className="border-0 shadow-xl bg-white/80 backdrop-blur-sm">
              <CardContent className="p-0">
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead className="bg-slate-50 border-b">
                      <tr>
                        <th className="text-left p-4 font-semibold text-slate-700">テンプレート名</th>
                        <th className="text-left p-4 font-semibold text-slate-700">種類</th>
                        <th className="text-left p-4 font-semibold text-slate-700">使用回数</th>
                        <th className="text-left p-4 font-semibold text-slate-700">最終使用</th>
                        <th className="text-left p-4 font-semibold text-slate-700">ステータス</th>
                        <th className="text-left p-4 font-semibold text-slate-700">操作</th>
                      </tr>
                    </thead>
                    <tbody>
                      {filteredTemplates.length > 0 ? (
                        filteredTemplates.map((template) => (
                          <tr key={template.id} className="border-b hover:bg-slate-50/50 transition-colors">
                            <td className="p-4 font-medium text-slate-900">{template.name}</td>
                            <td className="p-4 text-slate-600">{template.type}</td>
                            <td className="p-4 text-slate-600">{template.usage.toLocaleString()}</td>
                            <td className="p-4 text-slate-600">{template.lastUsed}</td>
                            <td className="p-4">{getStatusBadge(template.status)}</td>
                            <td className="p-4">
                              <div className="flex gap-2">
                                <Button
                                  size="sm"
                                  variant="outline"
                                  className="h-8 w-8 p-0"
                                  onClick={() => {
                                    setEditingTemplate(template)
                                    setIsTemplateDialogOpen(true)
                                  }}
                                >
                                  <Edit className="w-4 h-4" />
                                </Button>
                                <Button
                                  size="sm"
                                  variant="outline"
                                  className="h-8 w-8 p-0 text-red-600 hover:text-red-700"
                                  onClick={() => {
                                    setDeleteConfirmId(template.id)
                                    setDeleteConfirmType("template")
                                  }}
                                >
                                  <Trash2 className="w-4 h-4" />
                                </Button>
                              </div>
                            </td>
                          </tr>
                        ))
                      ) : (
                        <tr>
                          <td colSpan={6} className="p-8 text-center text-slate-500">
                            {searchQuery ? "検索条件に一致するテンプレートがありません" : "テンプレートがありません"}
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="users" className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-bold text-slate-800">ユーザー管理</h2>
              <Dialog open={isUserDialogOpen} onOpenChange={setIsUserDialogOpen}>
                <DialogTrigger asChild>
                  <Button
                    onClick={() => {
                      setEditingUser(null)
                      setIsUserDialogOpen(true)
                    }}
                    className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700"
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    新規ユーザー
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>{editingUser ? "ユーザー編集" : "新規ユーザー作成"}</DialogTitle>
                    <DialogDescription>ユーザーの詳細情報を入力してください</DialogDescription>
                  </DialogHeader>
                  <UserForm user={editingUser} onSave={handleSaveUser} onCancel={() => setIsUserDialogOpen(false)} />
                </DialogContent>
              </Dialog>
            </div>

            <Card className="border-0 shadow-xl bg-white/80 backdrop-blur-sm">
              <CardContent className="p-0">
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead className="bg-slate-50 border-b">
                      <tr>
                        <th className="text-left p-4 font-semibold text-slate-700">ユーザー名</th>
                        <th className="text-left p-4 font-semibold text-slate-700">メールアドレス</th>
                        <th className="text-left p-4 font-semibold text-slate-700">権限</th>
                        <th className="text-left p-4 font-semibold text-slate-700">最終アクセス</th>
                        <th className="text-left p-4 font-semibold text-slate-700">作成数</th>
                        <th className="text-left p-4 font-semibold text-slate-700">操作</th>
                      </tr>
                    </thead>
                    <tbody>
                      {filteredUsers.length > 0 ? (
                        filteredUsers.map((user) => (
                          <tr key={user.id} className="border-b hover:bg-slate-50/50 transition-colors">
                            <td className="p-4 font-medium text-slate-900">{user.name}</td>
                            <td className="p-4 text-slate-600">{user.email}</td>
                            <td className="p-4">{getRoleBadge(user.role)}</td>
                            <td className="p-4 text-slate-600">{user.lastActive}</td>
                            <td className="p-4 text-slate-600">{user.alertsCreated}</td>
                            <td className="p-4">
                              <div className="flex gap-2">
                                <Button
                                  size="sm"
                                  variant="outline"
                                  className="h-8 w-8 p-0"
                                  onClick={() => {
                                    setEditingUser(user)
                                    setIsUserDialogOpen(true)
                                  }}
                                >
                                  <Edit className="w-4 h-4" />
                                </Button>
                                <Button
                                  size="sm"
                                  variant="outline"
                                  className="h-8 w-8 p-0 text-red-600 hover:text-red-700"
                                  onClick={() => {
                                    setDeleteConfirmId(user.id)
                                    setDeleteConfirmType("user")
                                  }}
                                >
                                  <Trash2 className="w-4 h-4" />
                                </Button>
                              </div>
                            </td>
                          </tr>
                        ))
                      ) : (
                        <tr>
                          <td colSpan={6} className="p-8 text-center text-slate-500">
                            {searchQuery ? "検索条件に一致するユーザーがありません" : "ユーザーがありません"}
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="settings" className="space-y-6">
            <h2 className="text-2xl font-bold text-slate-800">システム設定</h2>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card className="border-0 shadow-xl bg-white/80 backdrop-blur-sm">
                <CardHeader className="bg-gradient-to-r from-slate-50 to-slate-100 rounded-t-lg">
                  <CardTitle className="text-slate-800">基本設定</CardTitle>
                  <CardDescription>システムの基本的な設定</CardDescription>
                </CardHeader>
                <CardContent className="p-6 space-y-4">
                  <div>
                    <Label htmlFor="system-name">システム名</Label>
                    <Input
                      id="system-name"
                      value={settings.systemName}
                      onChange={(e) => setSettings({ ...settings, systemName: e.target.value })}
                      className="mt-1"
                    />
                  </div>
                  <div>
                    <Label htmlFor="max-users">最大ユーザー数</Label>
                    <Input
                      id="max-users"
                      type="number"
                      value={settings.maxUsers}
                      onChange={(e) => setSettings({ ...settings, maxUsers: Number(e.target.value) })}
                      className="mt-1"
                    />
                  </div>
                  <div>
                    <Label htmlFor="storage-limit">ストレージ制限 (GB)</Label>
                    <Input
                      id="storage-limit"
                      type="number"
                      value={settings.storageLimit}
                      onChange={(e) => setSettings({ ...settings, storageLimit: Number(e.target.value) })}
                      className="mt-1"
                    />
                  </div>
                  <Button onClick={handleSaveSettings} className="w-full">
                    <Save className="w-4 h-4 mr-2" />
                    設定を保存
                  </Button>
                </CardContent>
              </Card>

              <Card className="border-0 shadow-xl bg-white/80 backdrop-blur-sm">
                <CardHeader className="bg-gradient-to-r from-slate-50 to-slate-100 rounded-t-lg">
                  <CardTitle className="text-slate-800">通知設定</CardTitle>
                  <CardDescription>システム通知の設定</CardDescription>
                </CardHeader>
                <CardContent className="p-6 space-y-4">
                  <div>
                    <Label htmlFor="email-notifications">メール通知</Label>
                    <Input
                      id="email-notifications"
                      value={settings.emailNotifications}
                      onChange={(e) => setSettings({ ...settings, emailNotifications: e.target.value })}
                      className="mt-1"
                    />
                  </div>
                  <div>
                    <Label htmlFor="alert-threshold">警告閾値</Label>
                    <Input
                      id="alert-threshold"
                      type="number"
                      value={settings.alertThreshold}
                      onChange={(e) => setSettings({ ...settings, alertThreshold: Number(e.target.value) })}
                      className="mt-1"
                    />
                  </div>
                  <div>
                    <Label htmlFor="backup-frequency">バックアップ頻度</Label>
                    <Input
                      id="backup-frequency"
                      value={settings.backupFrequency}
                      onChange={(e) => setSettings({ ...settings, backupFrequency: e.target.value })}
                      className="mt-1"
                    />
                  </div>
                  <Button onClick={handleSaveSettings} className="w-full">
                    <Save className="w-4 h-4 mr-2" />
                    設定を保存
                  </Button>
                </CardContent>
              </Card>

              <Card className="border-0 shadow-xl bg-white/80 backdrop-blur-sm lg:col-span-2">
                <CardHeader className="bg-gradient-to-r from-slate-50 to-slate-100 rounded-t-lg">
                  <CardTitle className="text-slate-800">システムメンテナンス</CardTitle>
                  <CardDescription>システムのバックアップと復元</CardDescription>
                </CardHeader>
                <CardContent className="p-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-4">
                      <h3 className="text-lg font-semibold text-slate-800">バックアップ</h3>
                      <p className="text-sm text-slate-600">
                        システムデータのバックアップを作成します。
                        {settings.lastBackup && (
                          <>
                            <br />
                            最終バックアップ: {new Date(settings.lastBackup).toLocaleString()}
                          </>
                        )}
                      </p>
                      <Button onClick={handleCreateBackup} className="w-full">
                        <RefreshCw className="w-4 h-4 mr-2" />
                        バックアップを作成
                      </Button>
                    </div>
                    <div className="space-y-4">
                      <h3 className="text-lg font-semibold text-slate-800">データリセット</h3>
                      <p className="text-sm text-slate-600">
                        すべてのデータを初期状態にリセットします。この操作は元に戻せません。
                      </p>
                      <Button
                        variant="destructive"
                        className="w-full"
                        onClick={() => {
                          if (window.confirm("本当にすべてのデータをリセットしますか？この操作は元に戻せません。")) {
                            setTemplates(initialTemplates)
                            setUsers(initialUsers)
                            setSettings(initialSettings)
                            toast({
                              title: "データをリセットしました",
                              description: "すべてのデータが初期状態に戻されました",
                            })
                          }
                        }}
                      >
                        <AlertTriangle className="w-4 h-4 mr-2" />
                        データをリセット
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>

      {/* 削除確認ダイアログ */}
      <AlertDialog
        open={deleteConfirmId !== null}
        onOpenChange={(open) => {
          if (!open) {
            setDeleteConfirmId(null)
            setDeleteConfirmType(null)
          }
        }}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>削除の確認</AlertDialogTitle>
            <AlertDialogDescription>
              {deleteConfirmType === "template"
                ? "このテンプレートを削除しますか？この操作は元に戻せません。"
                : "このユーザーを削除しますか？この操作は元に戻せません。"}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>キャンセル</AlertDialogCancel>
            <AlertDialogAction
              className="bg-red-600 hover:bg-red-700"
              onClick={() => {
                if (deleteConfirmId) {
                  if (deleteConfirmType === "template") {
                    handleDeleteTemplate(deleteConfirmId)
                  } else if (deleteConfirmType === "user") {
                    handleDeleteUser(deleteConfirmId)
                  }
                }
                setDeleteConfirmId(null)
                setDeleteConfirmType(null)
              }}
            >
              削除
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}

// テンプレートフォームコンポーネント
function TemplateForm({
  template,
  onSave,
  onCancel,
}: {
  template: Template | null
  onSave: (template: Omit<Template, "id" | "usage" | "lastUsed" | "createdAt" | "updatedAt">) => void
  onCancel: () => void
}) {
  const [formData, setFormData] = useState({
    name: template?.name || "",
    type: template?.type || "heavyRainSpecial",
    message: template?.message || "",
    targetArea: template?.targetArea || "",
    backgroundColor: template?.backgroundColor || "#dc2626",
    textColor: template?.textColor || "#ffffff",
    status: template?.status || "active",
  })
  const [errors, setErrors] = useState<Record<string, string>>({})

  useEffect(() => {
    if (template) {
      setFormData({
        name: template.name,
        type: template.type,
        message: template.message,
        targetArea: template.targetArea,
        backgroundColor: template.backgroundColor,
        textColor: template.textColor,
        status: template.status,
      })
    }
  }, [template])

  const validateForm = () => {
    const newErrors: Record<string, string> = {}

    if (!formData.name.trim()) {
      newErrors.name = "テンプレート名は必須です"
    }

    if (!formData.type.trim()) {
      newErrors.type = "種類は必須です"
    }

    if (!formData.message.trim()) {
      newErrors.message = "メッセージは必須です"
    }

    if (!formData.targetArea.trim()) {
      newErrors.targetArea = "対象地域は必須です"
    }

    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    if (validateForm()) {
      onSave(formData as Omit<Template, "id" | "usage" | "lastUsed" | "createdAt" | "updatedAt">)
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <Label htmlFor="template-name" className={errors.name ? "text-red-500" : ""}>
          テンプレート名
        </Label>
        <Input
          id="template-name"
          value={formData.name}
          onChange={(e) => {
            setFormData({ ...formData, name: e.target.value })
            if (errors.name) {
              setErrors({ ...errors, name: "" })
            }
          }}
          className={errors.name ? "border-red-500" : ""}
          required
        />
        {errors.name && <p className="text-red-500 text-sm mt-1">{errors.name}</p>}
      </div>
      <div>
        <Label htmlFor="template-type" className={errors.type ? "text-red-500" : ""}>
          種類
        </Label>
        <Input
          id="template-type"
          value={formData.type}
          onChange={(e) => {
            setFormData({ ...formData, type: e.target.value })
            if (errors.type) {
              setErrors({ ...errors, type: "" })
            }
          }}
          className={errors.type ? "border-red-500" : ""}
          required
        />
        {errors.type && <p className="text-red-500 text-sm mt-1">{errors.type}</p>}
      </div>
      <div>
        <Label htmlFor="template-message" className={errors.message ? "text-red-500" : ""}>
          メッセージ
        </Label>
        <Textarea
          id="template-message"
          value={formData.message}
          onChange={(e) => {
            setFormData({ ...formData, message: e.target.value })
            if (errors.message) {
              setErrors({ ...errors, message: "" })
            }
          }}
          className={errors.message ? "border-red-500" : ""}
          required
        />
        {errors.message && <p className="text-red-500 text-sm mt-1">{errors.message}</p>}
      </div>
      <div>
        <Label htmlFor="template-area" className={errors.targetArea ? "text-red-500" : ""}>
          対象地域
        </Label>
        <Input
          id="template-area"
          value={formData.targetArea}
          onChange={(e) => {
            setFormData({ ...formData, targetArea: e.target.value })
            if (errors.targetArea) {
              setErrors({ ...errors, targetArea: "" })
            }
          }}
          className={errors.targetArea ? "border-red-500" : ""}
          required
        />
        {errors.targetArea && <p className="text-red-500 text-sm mt-1">{errors.targetArea}</p>}
      </div>
      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label htmlFor="template-bg">背景色</Label>
          <div className="flex gap-2 mt-1">
            <Input
              id="template-bg"
              type="color"
              value={formData.backgroundColor}
              onChange={(e) => setFormData({ ...formData, backgroundColor: e.target.value })}
              className="w-12 h-10 p-1"
            />
            <Input
              value={formData.backgroundColor}
              onChange={(e) => setFormData({ ...formData, backgroundColor: e.target.value })}
              className="flex-1"
            />
          </div>
        </div>
        <div>
          <Label htmlFor="template-text">文字色</Label>
          <div className="flex gap-2 mt-1">
            <Input
              id="template-text"
              type="color"
              value={formData.textColor}
              onChange={(e) => setFormData({ ...formData, textColor: e.target.value })}
              className="w-12 h-10 p-1"
            />
            <Input
              value={formData.textColor}
              onChange={(e) => setFormData({ ...formData, textColor: e.target.value })}
              className="flex-1"
            />
          </div>
        </div>
      </div>
      <div>
        <Label htmlFor="template-status">ステータス</Label>
        <Select value={formData.status} onValueChange={(value) => setFormData({ ...formData, status: value as any })}>
          <SelectTrigger>
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="active">アクティブ</SelectItem>
            <SelectItem value="draft">下書き</SelectItem>
            <SelectItem value="archived">アーカイブ</SelectItem>
          </SelectContent>
        </Select>
      </div>
      <DialogFooter className="pt-4">
        <Button type="button" variant="outline" onClick={onCancel}>
          <X className="w-4 h-4 mr-2" />
          キャンセル
        </Button>
        <Button type="submit">
          <Save className="w-4 h-4 mr-2" />
          保存
        </Button>
      </DialogFooter>
    </form>
  )
}

// ユーザーフォームコンポーネント
function UserForm({
  user,
  onSave,
  onCancel,
}: {
  user: User | null
