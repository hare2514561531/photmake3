"use client"

import { useState, useEffect } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import AlertImageGenerator from "../alert-image-generator"
import AdminDashboard from "../components/admin-dashboard"
import AdminLogin from "../components/admin-login"
import { Shield, ImageIcon } from "lucide-react"

export default function Page() {
  const [isAdminAuthenticated, setIsAdminAuthenticated] = useState(false)
  const [isCheckingAuth, setIsCheckingAuth] = useState(true)

  useEffect(() => {
    // 認証状態をチェック
    const checkAuth = () => {
      const isAuthenticated = localStorage.getItem("adminAuthenticated") === "true"
      const loginTime = localStorage.getItem("adminLoginTime")

      if (isAuthenticated && loginTime) {
        // 24時間でセッション期限切れ
        const now = Date.now()
        const loginTimestamp = Number.parseInt(loginTime)
        const sessionDuration = 24 * 60 * 60 * 1000 // 24時間

        if (now - loginTimestamp < sessionDuration) {
          setIsAdminAuthenticated(true)
        } else {
          // セッション期限切れ
          localStorage.removeItem("adminAuthenticated")
          localStorage.removeItem("adminLoginTime")
          setIsAdminAuthenticated(false)
        }
      }
      setIsCheckingAuth(false)
    }

    checkAuth()
  }, [])

  const handleLogin = (success: boolean) => {
    setIsAdminAuthenticated(success)
  }

  const handleLogout = () => {
    setIsAdminAuthenticated(false)
  }

  if (isCheckingAuth) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-slate-600">認証状態を確認中...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen">
      <Tabs defaultValue="generator" className="w-full">
        <div className="bg-white border-b shadow-sm">
          <div className="container mx-auto">
            <TabsList className="grid w-full max-w-md grid-cols-2 bg-transparent border-0 h-16">
              <TabsTrigger
                value="generator"
                className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-blue-500 data-[state=active]:to-indigo-500 data-[state=active]:text-white h-12 text-base font-semibold"
              >
                <ImageIcon className="w-5 h-5 mr-2" />
                画像作成
              </TabsTrigger>
              <TabsTrigger
                value="admin"
                className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-blue-500 data-[state=active]:to-indigo-500 data-[state=active]:text-white h-12 text-base font-semibold"
              >
                <Shield className="w-5 h-5 mr-2" />
                管理画面
              </TabsTrigger>
            </TabsList>
          </div>
        </div>

        <TabsContent value="generator" className="mt-0">
          <AlertImageGenerator />
        </TabsContent>

        <TabsContent value="admin" className="mt-0">
          {isAdminAuthenticated ? <AdminDashboard onLogout={handleLogout} /> : <AdminLogin onLogin={handleLogin} />}
        </TabsContent>
      </Tabs>
    </div>
  )
}
