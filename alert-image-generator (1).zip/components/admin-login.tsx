"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Shield, Eye, EyeOff, AlertCircle } from "lucide-react"
import { toast } from "@/hooks/use-toast"
import { Alert, AlertDescription } from "@/components/ui/alert"

interface AdminLoginProps {
  onLogin: (success: boolean) => void
}

export default function AdminLogin({ onLogin }: AdminLoginProps) {
  const [password, setPassword] = useState("")
  const [showPassword, setShowPassword] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [loginAttempts, setLoginAttempts] = useState(0)
  const [isLocked, setIsLocked] = useState(false)
  const [lockoutTime, setLockoutTime] = useState<number | null>(null)
  const [timeRemaining, setTimeRemaining] = useState<number | null>(null)

  // 管理者パスワード（実際の運用では環境変数やサーバーサイドで管理）
  const ADMIN_PASSWORD = "kuma2024"
  const MAX_LOGIN_ATTEMPTS = 5
  const LOCKOUT_DURATION = 15 * 60 * 1000 // 15分

  // ロックアウト状態をチェック
  useState(() => {
    const storedLockoutTime = localStorage.getItem("adminLockoutTime")
    if (storedLockoutTime) {
      const lockTime = Number.parseInt(storedLockoutTime)
      const now = Date.now()

      if (now < lockTime) {
        setIsLocked(true)
        setLockoutTime(lockTime)
        setTimeRemaining(Math.ceil((lockTime - now) / 1000 / 60))

        // タイマーを設定して残り時間を更新
        const timer = setInterval(() => {
          const currentTime = Date.now()
          if (currentTime >= lockTime) {
            setIsLocked(false)
            setLockoutTime(null)
            setTimeRemaining(null)
            localStorage.removeItem("adminLockoutTime")
            clearInterval(timer)
          } else {
            setTimeRemaining(Math.ceil((lockTime - currentTime) / 1000 / 60))
          }
        }, 60000) // 1分ごとに更新

        return () => clearInterval(timer)
      } else {
        localStorage.removeItem("adminLockoutTime")
      }
    }

    const storedAttempts = localStorage.getItem("adminLoginAttempts")
    if (storedAttempts) {
      setLoginAttempts(Number.parseInt(storedAttempts))
    }
  })

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()

    if (isLocked) {
      toast({
        title: "アカウントがロックされています",
        description: `${timeRemaining}分後に再試行してください`,
        variant: "destructive",
      })
      return
    }

    setIsLoading(true)

    // 簡単な遅延でリアルな認証体験を演出
    await new Promise((resolve) => setTimeout(resolve, 1000))

    if (password === ADMIN_PASSWORD) {
      // ログイン成功
      localStorage.setItem("adminAuthenticated", "true")
      localStorage.setItem("adminLoginTime", Date.now().toString())
      localStorage.removeItem("adminLoginAttempts")

      toast({
        title: "ログイン成功",
        description: "管理画面にアクセスしました",
      })
      onLogin(true)
    } else {
      // ログイン失敗
      const attempts = loginAttempts + 1
      setLoginAttempts(attempts)
      localStorage.setItem("adminLoginAttempts", attempts.toString())

      if (attempts >= MAX_LOGIN_ATTEMPTS) {
        // アカウントをロック
        const lockTime = Date.now() + LOCKOUT_DURATION
        setIsLocked(true)
        setLockoutTime(lockTime)
        setTimeRemaining(Math.ceil(LOCKOUT_DURATION / 1000 / 60))
        localStorage.setItem("adminLockoutTime", lockTime.toString())

        toast({
          title: "アカウントがロックされました",
          description: `セキュリティのため、${Math.ceil(LOCKOUT_DURATION / 1000 / 60)}分間ログインできません`,
          variant: "destructive",
        })
      } else {
        toast({
          title: "ログイン失敗",
          description: `パスワードが正しくありません。残り試行回数: ${MAX_LOGIN_ATTEMPTS - attempts}回`,
          variant: "destructive",
        })
      }

      onLogin(false)
    }

    setIsLoading(false)
    setPassword("")
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50 flex items-center justify-center p-6">
      <Card className="w-full max-w-md border-0 shadow-2xl bg-white/90 backdrop-blur-sm">
        <CardHeader className="text-center bg-gradient-to-r from-slate-50 to-slate-100 rounded-t-lg">
          <div className="mx-auto w-16 h-16 bg-gradient-to-r from-blue-500 to-indigo-500 rounded-full flex items-center justify-center mb-4">
            <Shield className="w-8 h-8 text-white" />
          </div>
          <CardTitle className="text-2xl font-bold text-slate-800">管理者認証</CardTitle>
          <CardDescription>管理画面にアクセスするにはパスワードが必要です</CardDescription>
        </CardHeader>
        <CardContent className="p-6">
          {isLocked ? (
            <Alert variant="destructive" className="mb-6">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>
                セキュリティのため、アカウントが一時的にロックされています。
                {timeRemaining && `${timeRemaining}分後に再試行してください。`}
              </AlertDescription>
            </Alert>
          ) : (
            <form onSubmit={handleLogin} className="space-y-6">
              <div>
                <Label htmlFor="password" className="text-sm font-semibold text-slate-700">
                  管理者パスワード
                </Label>
                <div className="relative mt-2">
                  <Input
                    id="password"
                    type={showPassword ? "text" : "password"}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="パスワードを入力してください"
                    className="pr-10 border-slate-200 focus:border-blue-500 focus:ring-blue-500"
                    required
                    autoComplete="current-password"
                  />
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    className="absolute right-0 top-0 h-full px-3 py-2 hover:bg-transparent"
                    onClick={() => setShowPassword(!showPassword)}
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </Button>
                </div>
              </div>

              <Button
                type="submit"
                className="w-full h-12 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white font-semibold"
                disabled={isLoading || isLocked}
              >
                {isLoading ? "認証中..." : "ログイン"}
              </Button>
            </form>
          )}

          <div className="mt-6 p-4 bg-blue-50 rounded-lg">
            <p className="text-sm text-blue-800">
              <strong>デモ用パスワード:</strong> admin2024
            </p>
            <p className="text-xs text-blue-600 mt-1">実際の運用では強力なパスワードを設定してください</p>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
