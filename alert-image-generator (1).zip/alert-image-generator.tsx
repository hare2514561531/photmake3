"use client"

import { useState, useRef, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import {
  Download,
  AlertTriangle,
  Flame,
  Zap,
  CloudRain,
  Wind,
  Settings,
  Palette,
  Type,
  Share2,
  Twitter,
  Facebook,
  Mail,
  MessageCircle,
} from "lucide-react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { toast } from "@/hooks/use-toast"

interface AlertConfig {
  type: string
  level: string
  message: string
  targetArea: string
  backgroundColor: string
  textColor: string
  credit: string
}

interface AlertTypeInfo {
  value: string
  label: string
  icon: any
  color: string
  defaultMessage: string
}

const alertTypes: AlertTypeInfo[] = [
  { value: "heavyRain", label: "大雨警報", icon: CloudRain, color: "#dc2626", defaultMessage: "命を守る行動を！" },
  {
    value: "heavyRainSpecial",
    label: "大雨特別警報",
    icon: CloudRain,
    color: "#dc2626",
    defaultMessage: "命を守る行動を！",
  },
  {
    value: "flood",
    label: "洪水警報",
    icon: CloudRain,
    color: "#2563eb",
    defaultMessage: "速やかに安全な場所へ避難を！",
  },
  {
    value: "storm",
    label: "暴風警報",
    icon: Wind,
    color: "#7c3aed",
    defaultMessage: "外出を控え、頑丈な建物内に待機を！",
  },
  { value: "tsunami", label: "津波警報", icon: Wind, color: "#0891b2", defaultMessage: "直ちに高台へ避難を！" },
  {
    value: "tsunamiSpecial",
    label: "大津波警報",
    icon: Wind,
    color: "#0891b2",
    defaultMessage: "直ちに高台へ避難を！",
  },
  {
    value: "earthquake",
    label: "地震警報",
    icon: AlertTriangle,
    color: "#ea580c",
    defaultMessage: "落ち着いて身の安全を確保してください！",
  },
  { value: "fire", label: "火災警報", icon: Flame, color: "#dc2626", defaultMessage: "直ちに避難してください！" },
  { value: "thunder", label: "雷警報", icon: Zap, color: "#facc15", defaultMessage: "建物内に避難してください！" },
  {
    value: "volcano",
    label: "火山警報",
    icon: Flame,
    color: "#dc2626",
    defaultMessage: "直ちに危険区域から離れてください！",
  },
  {
    value: "heatwave",
    label: "熱中症警報",
    icon: AlertTriangle,
    color: "#f97316",
    defaultMessage: "水分をこまめに取り、涼しい場所で休憩を！",
  },
  {
    value: "general",
    label: "一般警報",
    icon: AlertTriangle,
    color: "#dc2626",
    defaultMessage: "今後の情報に注意してください！",
  },
]

const alertLevels = [
  { value: "info", label: "注意報", color: "#3b82f6" },
  { value: "warning", label: "警報", color: "#f59e0b" },
  { value: "danger", label: "特別警報", color: "#dc2626" },
  { value: "emergency", label: "緊急警報", color: "#991b1b" },
]

export default function AlertImageGenerator() {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [config, setConfig] = useState<AlertConfig>({
    type: "heavyRainSpecial",
    level: "danger",
    message: "命を守る行動を！",
    targetArea: "名古屋市",
    backgroundColor: "#dc2626",
    textColor: "#ffffff",
    credit: "画像制作: EWC画像制作部",
  })

  const [shareUrl, setShareUrl] = useState("")
  const [copied, setCopied] = useState(false)

  const updateConfig = (key: keyof AlertConfig, value: any) => {
    setConfig((prev) => ({ ...prev, [key]: value }))
  }

  const getAlertTypeInfo = (type: string): AlertTypeInfo => {
    return alertTypes.find((t) => t.value === type) || alertTypes[alertTypes.length - 1]
  }

  const handleAlertTypeChange = (value: string) => {
    const alertTypeInfo = getAlertTypeInfo(value)
    updateConfig("type", value)
    updateConfig("backgroundColor", alertTypeInfo.color)
    updateConfig("message", alertTypeInfo.defaultMessage)
  }

  // 日本語テキストを適切な単位で分割する関数
  const segmentJapaneseText = (text: string): string[] => {
    const locationSuffixes = [
      "都",
      "道",
      "府",
      "県",
      "市",
      "区",
      "町",
      "村",
      "郡",
      "島",
      "半島",
      "山",
      "川",
      "湖",
      "海",
      "湾",
      "丁目",
      "番地",
      "号",
    ]
    const separators = [" ", "　", "・", "、", "，", ",", "及び", "および", "と"]

    const segments: string[] = []
    let currentSegment = ""

    for (let i = 0; i < text.length; i++) {
      const char = text[i]
      currentSegment += char

      if (separators.includes(char)) {
        if (currentSegment.trim()) {
          segments.push(currentSegment.trim())
        }
        currentSegment = ""
        continue
      }

      if (locationSuffixes.includes(char)) {
        const nextChar = text[i + 1]
        if (!nextChar || !locationSuffixes.includes(nextChar)) {
          if (currentSegment.trim()) {
            segments.push(currentSegment.trim())
          }
          currentSegment = ""
        }
      }
    }

    if (currentSegment.trim()) {
      segments.push(currentSegment.trim())
    }

    return segments.filter((segment) => segment.length > 0)
  }

  const wrapTextByWords = (ctx: CanvasRenderingContext2D, text: string, maxWidth: number): string[] => {
    const segments = segmentJapaneseText(text)
    const lines: string[] = []
    let currentLine = ""

    for (const segment of segments) {
      const testLine = currentLine + segment
      const metrics = ctx.measureText(testLine)

      if (metrics.width > maxWidth && currentLine !== "") {
        lines.push(currentLine.trim())
        currentLine = segment
      } else {
        currentLine = testLine
      }
    }

    if (currentLine.trim() !== "") {
      lines.push(currentLine.trim())
    }

    const finalLines: string[] = []
    for (const line of lines) {
      const lineWidth = ctx.measureText(line).width
      if (lineWidth > maxWidth) {
        const charLines = wrapTextByChars(ctx, line, maxWidth)
        finalLines.push(...charLines)
      } else {
        finalLines.push(line)
      }
    }

    return finalLines.length > 0 ? finalLines : [text]
  }

  const wrapTextByChars = (ctx: CanvasRenderingContext2D, text: string, maxWidth: number): string[] => {
    const lines: string[] = []
    let currentLine = ""

    for (const char of text) {
      const testLine = currentLine + char
      const metrics = ctx.measureText(testLine)

      if (metrics.width > maxWidth && currentLine !== "") {
        lines.push(currentLine)
        currentLine = char
      } else {
        currentLine = testLine
      }
    }

    if (currentLine !== "") {
      lines.push(currentLine)
    }

    return lines.length > 0 ? lines : [text]
  }

  const processAreaText = (ctx: CanvasRenderingContext2D, areaText: string, maxWidth: number): string[] => {
    const inputLines = areaText.split("\n").filter((line) => line.trim() !== "")
    const processedLines: string[] = []

    for (const line of inputLines) {
      const wrappedLines = wrapTextByWords(ctx, line.trim(), maxWidth)
      processedLines.push(...wrappedLines)
    }

    return processedLines
  }

  const adjustColor = (hex: string, amount: number): string => {
    let r = Number.parseInt(hex.substring(1, 3), 16)
    let g = Number.parseInt(hex.substring(3, 5), 16)
    let b = Number.parseInt(hex.substring(5, 7), 16)

    r = Math.max(0, Math.min(255, r + amount))
    g = Math.max(0, Math.min(255, g + amount))
    b = Math.max(0, Math.min(255, b + amount))

    return `#${r.toString(16).padStart(2, "0")}${g.toString(16).padStart(2, "0")}${b.toString(16).padStart(2, "0")}`
  }

  const drawAlert = () => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    canvas.width = 2060
    canvas.height = 1456

    // 背景色
    ctx.fillStyle = config.backgroundColor
    ctx.fillRect(0, 0, canvas.width, canvas.height)

    // おしゃれな背景効果
    const gradient = ctx.createLinearGradient(0, 0, canvas.width, canvas.height)
    gradient.addColorStop(0, config.backgroundColor)
    gradient.addColorStop(0.5, adjustColor(config.backgroundColor, -20))
    gradient.addColorStop(1, adjustColor(config.backgroundColor, -40))
    ctx.fillStyle = gradient
    ctx.fillRect(0, 0, canvas.width, canvas.height)

    // 微妙なパターン効果
    ctx.globalAlpha = 0.03
    for (let i = 0; i < 30; i++) {
      const x = Math.random() * canvas.width
      const y = Math.random() * canvas.height
      const radius = Math.random() * 150 + 50
      ctx.beginPath()
      ctx.arc(x, y, radius, 0, Math.PI * 2)
      ctx.fillStyle = "#ffffff"
      ctx.fill()
    }
    ctx.globalAlpha = 1.0

    let currentY = 150

    // 警報名
    const selectedType = getAlertTypeInfo(config.type)
    const alertName = `${selectedType.label}`

    ctx.fillStyle = config.textColor
    ctx.font = `bold 180px sans-serif`
    ctx.textAlign = "center"
    ctx.textBaseline = "middle"

    // テキストに影を追加
    ctx.shadowColor = "rgba(0, 0, 0, 0.3)"
    ctx.shadowBlur = 10
    ctx.shadowOffsetX = 3
    ctx.shadowOffsetY = 3

    ctx.fillText(alertName, canvas.width / 2, currentY)
    currentY += 180

    // メッセージ
    ctx.font = `bold 100px sans-serif`
    ctx.textBaseline = "middle"
    const messageLines = config.message.split("\n")
    messageLines.forEach((line) => {
      ctx.fillText(line, canvas.width / 2, currentY)
      currentY += 120
    })
    currentY += 40

    // 影をリセット
    ctx.shadowColor = "transparent"
    ctx.shadowBlur = 0
    ctx.shadowOffsetX = 0
    ctx.shadowOffsetY = 0

    // 白い横線
    ctx.strokeStyle = config.textColor
    ctx.lineWidth = 8
    ctx.beginPath()
    ctx.moveTo(0, currentY)
    ctx.lineTo(canvas.width, currentY)
    ctx.stroke()
    currentY += 120

    // 対象地域の処理
    const maxBoxWidth = canvas.width - 200
    const minBoxWidth = 800
    const horizontalPadding = 60
    const verticalPadding = 40
    const lineHeight = 100

    ctx.font = `bold 80px sans-serif`

    const maxTextWidth = maxBoxWidth - horizontalPadding * 2
    const processedLines = processAreaText(ctx, config.targetArea, maxTextWidth)

    const actualTextWidth = Math.max(...processedLines.map((line) => ctx.measureText(line).width))
    const areaBoxWidth = Math.min(maxBoxWidth, Math.max(minBoxWidth, actualTextWidth + horizontalPadding * 2))

    const lineCount = processedLines.length
    const areaBoxHeight = lineCount * lineHeight + verticalPadding * 2

    const areaBoxX = (canvas.width - areaBoxWidth) / 2
    const areaBoxY = currentY - 20
    const cornerRadius = 40

    // 白い角丸の背景（枠線なし）
    ctx.fillStyle = "#ffffff"
    ctx.beginPath()
    ctx.roundRect(areaBoxX, areaBoxY, areaBoxWidth, areaBoxHeight, cornerRadius)
    ctx.fill()

    // 対象地域のテキスト（黒文字）
    ctx.fillStyle = "#000000"
    ctx.font = `bold 80px sans-serif`
    ctx.textAlign = "center"
    ctx.textBaseline = "middle"

    const startY = areaBoxY + verticalPadding + lineHeight / 2
    processedLines.forEach((line, index) => {
      const textY = startY + index * lineHeight
      ctx.fillText(line, canvas.width / 2, textY)
    })

    currentY = areaBoxY + areaBoxHeight + 60

    // クレジット
    ctx.fillStyle = config.textColor
    ctx.font = "40px sans-serif"
    ctx.textAlign = "left"
    ctx.fillText(config.credit, 40, canvas.height - 40)
  }

  useEffect(() => {
    drawAlert()
  }, [config])

  const downloadImage = () => {
    const canvas = canvasRef.current
    if (!canvas) return

    const link = document.createElement("a")
    link.download = `alert-${config.type}-${Date.now()}.png`
    link.href = canvas.toDataURL("image/png", 1.0)
    link.click()
  }

  const generateShareUrl = () => {
    const params = new URLSearchParams({
      type: config.type,
      message: config.message,
      area: config.targetArea,
      bg: config.backgroundColor,
      text: config.textColor,
    })
    return `${window.location.origin}${window.location.pathname}?${params.toString()}`
  }

  const shareToTwitter = () => {
    const url = generateShareUrl()
    const text = `${config.message} - ${config.targetArea}の警報画像を作成しました`
    window.open(`https://twitter.com/intent/tweet?text=${encodeURIComponent(text)}&url=${encodeURIComponent(url)}`)
  }

  const shareToFacebook = () => {
    const url = generateShareUrl()
    window.open(`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}`)
  }

  const shareByEmail = () => {
    const url = generateShareUrl()
    const subject = `警報画像: ${config.message}`
    const body = `${config.targetArea}の警報画像を共有します。\n\n詳細: ${url}`
    window.open(`mailto:?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`)
  }

  const shareToLine = () => {
    const url = generateShareUrl()
    const text = `${config.message} - ${config.targetArea}の警報画像`
    window.open(
      `https://social-plugins.line.me/lineit/share?url=${encodeURIComponent(url)}&text=${encodeURIComponent(text)}`,
    )
  }

  const copyToClipboard = async () => {
    const url = generateShareUrl()
    try {
      await navigator.clipboard.writeText(url)
      setCopied(true)
      toast({
        title: "コピーしました",
        description: "共有URLがクリップボードにコピーされました",
      })
      setTimeout(() => setCopied(false), 2000)
    } catch (err) {
      toast({
        title: "エラー",
        description: "URLのコピーに失敗しました",
        variant: "destructive",
      })
    }
  }

  const generateQRCode = () => {
    const url = generateShareUrl()
    return `https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(url)}`
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50">
      <div className="container mx-auto p-6">
        <div className="text-center mb-8">
          <h1 className="text-5xl font-bold bg-gradient-to-r from-slate-900 via-blue-800 to-indigo-800 bg-clip-text text-transparent mb-4">
            警報画像作成ツール
          </h1>
          <p className="text-xl text-slate-600 max-w-2xl mx-auto">
            プロフェッショナルな警報画像を簡単に作成。地名の自動改行機能付き。
          </p>
          <Badge variant="secondary" className="mt-4 px-4 py-2 text-sm">
            Professional Edition
          </Badge>
        </div>

        <div className="grid grid-cols-1 xl:grid-cols-3 gap-8">
          {/* 設定パネル */}
          <div className="xl:col-span-1 space-y-6">
            <Tabs defaultValue="basic" className="w-full">
              <TabsList className="grid w-full grid-cols-3 bg-white shadow-sm border-0">
                <TabsTrigger
                  value="basic"
                  className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-blue-500 data-[state=active]:to-indigo-500 data-[state=active]:text-white"
                >
                  <Settings className="w-4 h-4 mr-2" />
                  基本
                </TabsTrigger>
                <TabsTrigger
                  value="design"
                  className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-blue-500 data-[state=active]:to-indigo-500 data-[state=active]:text-white"
                >
                  <Palette className="w-4 h-4 mr-2" />
                  デザイン
                </TabsTrigger>
                <TabsTrigger
                  value="text"
                  className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-blue-500 data-[state=active]:to-indigo-500 data-[state=active]:text-white"
                >
                  <Type className="w-4 h-4 mr-2" />
                  テキスト
                </TabsTrigger>
              </TabsList>

              <TabsContent value="basic" className="space-y-6 mt-6">
                <Card className="border-0 shadow-xl bg-white/90 backdrop-blur-sm">
                  <CardHeader className="bg-gradient-to-r from-slate-50 to-slate-100 rounded-t-lg">
                    <CardTitle className="text-slate-800 flex items-center gap-2">
                      <AlertTriangle className="w-5 h-5" />
                      警報設定
                    </CardTitle>
                    <CardDescription>警報の種類を選択すると、適切なメッセージが自動設定されます</CardDescription>
                  </CardHeader>
                  <CardContent className="p-6 space-y-6">
                    <div>
                      <Label htmlFor="alert-type" className="text-sm font-semibold text-slate-700">
                        警報の種類
                      </Label>
                      <Select value={config.type} onValueChange={handleAlertTypeChange}>
                        <SelectTrigger className="mt-2 border-slate-200 focus:border-blue-500 focus:ring-blue-500">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {alertTypes.map((type) => {
                            const Icon = type.icon
                            return (
                              <SelectItem key={type.value} value={type.value}>
                                <div className="flex items-center gap-3">
                                  <div className="w-4 h-4 rounded-full" style={{ backgroundColor: type.color }}></div>
                                  <Icon className="w-4 h-4" />
                                  {type.label}
                                </div>
                              </SelectItem>
                            )
                          })}
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <Label htmlFor="target-area" className="text-sm font-semibold text-slate-700">
                        対象地域
                      </Label>
                      <Textarea
                        id="target-area"
                        value={config.targetArea}
                        onChange={(e) => updateConfig("targetArea", e.target.value)}
                        placeholder="対象地域を入力（改行で複数地域を指定可能）"
                        rows={3}
                        className="mt-2 border-slate-200 focus:border-blue-500 focus:ring-blue-500"
                      />
                      <p className="text-xs text-slate-500 mt-2 bg-slate-50 p-2 rounded">
                        💡 地名は適切な位置で自動改行されます。「浜松市」が「浜」と「松市」に分かれることはありません。
                      </p>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="design" className="space-y-6 mt-6">
                <Card className="border-0 shadow-xl bg-white/90 backdrop-blur-sm">
                  <CardHeader className="bg-gradient-to-r from-slate-50 to-slate-100 rounded-t-lg">
                    <CardTitle className="text-slate-800 flex items-center gap-2">
                      <Palette className="w-5 h-5" />
                      色設定
                    </CardTitle>
                    <CardDescription>背景色と文字色をカスタマイズできます</CardDescription>
                  </CardHeader>
                  <CardContent className="p-6 space-y-6">
                    <div>
                      <Label htmlFor="bg-color" className="text-sm font-semibold text-slate-700">
                        背景色
                      </Label>
                      <div className="flex gap-3 mt-2">
                        <Input
                          id="bg-color"
                          type="color"
                          value={config.backgroundColor}
                          onChange={(e) => updateConfig("backgroundColor", e.target.value)}
                          className="w-16 h-12 p-1 border-slate-200"
                        />
                        <Input
                          value={config.backgroundColor}
                          onChange={(e) => updateConfig("backgroundColor", e.target.value)}
                          placeholder="#dc2626"
                          className="flex-1 border-slate-200 focus:border-blue-500 focus:ring-blue-500"
                        />
                      </div>
                    </div>

                    <div>
                      <Label htmlFor="text-color" className="text-sm font-semibold text-slate-700">
                        文字色
                      </Label>
                      <div className="flex gap-3 mt-2">
                        <Input
                          id="text-color"
                          type="color"
                          value={config.textColor}
                          onChange={(e) => updateConfig("textColor", e.target.value)}
                          className="w-16 h-12 p-1 border-slate-200"
                        />
                        <Input
                          value={config.textColor}
                          onChange={(e) => updateConfig("textColor", e.target.value)}
                          placeholder="#ffffff"
                          className="flex-1 border-slate-200 focus:border-blue-500 focus:ring-blue-500"
                        />
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="text" className="space-y-6 mt-6">
                <Card className="border-0 shadow-xl bg-white/90 backdrop-blur-sm">
                  <CardHeader className="bg-gradient-to-r from-slate-50 to-slate-100 rounded-t-lg">
                    <CardTitle className="text-slate-800 flex items-center gap-2">
                      <Type className="w-5 h-5" />
                      テキスト設定
                    </CardTitle>
                    <CardDescription>メッセージとクレジットの設定</CardDescription>
                  </CardHeader>
                  <CardContent className="p-6 space-y-6">
                    <div>
                      <Label htmlFor="message" className="text-sm font-semibold text-slate-700">
                        メッセージ
                      </Label>
                      <Textarea
                        id="message"
                        value={config.message}
                        onChange={(e) => updateConfig("message", e.target.value)}
                        placeholder="警報メッセージを入力（改行可能）"
                        rows={3}
                        className="mt-2 border-slate-200 focus:border-blue-500 focus:ring-blue-500"
                      />
                    </div>

                    <div>
                      <Label htmlFor="credit" className="text-sm font-semibold text-slate-700">
                        クレジット
                      </Label>
                      <Input
                        id="credit"
                        value={config.credit}
                        onChange={(e) => updateConfig("credit", e.target.value)}
                        placeholder="画像制作者名を入力"
                        className="mt-2 border-slate-200 focus:border-blue-500 focus:ring-blue-500"
                      />
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>

            <Button
              onClick={downloadImage}
              className="w-full h-14 text-lg bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 shadow-xl hover:shadow-2xl transition-all duration-300"
            >
              <Download className="w-5 h-5 mr-3" />
              高品質画像をダウンロード
            </Button>

            <Dialog>
              <DialogTrigger asChild>
                <Button
                  variant="outline"
                  className="w-full h-14 text-lg border-2 border-blue-200 hover:border-blue-400 hover:bg-blue-50 transition-all duration-300"
                >
                  <Share2 className="w-5 h-5 mr-3" />
                  画像を共有
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-md">
                <DialogHeader>
                  <DialogTitle className="flex items-center gap-2">
                    <Share2 className="w-5 h-5" />
                    警報画像を共有
                  </DialogTitle>
                  <DialogDescription>作成した警報画像を様々な方法で共有できます</DialogDescription>
                </DialogHeader>
                <div className="space-y-4">
                  {/* SNS共有ボタン */}
                  <div className="grid grid-cols-2 gap-3">
                    <Button onClick={shareToTwitter} className="bg-blue-500 hover:bg-blue-600 text-white">
                      <Twitter className="w-4 h-4 mr-2" />
                      Twitter
                    </Button>
                    <Button onClick={shareToFacebook} className="bg-blue-700 hover:bg-blue-800 text-white">
                      <Facebook className="w-4 h-4 mr-2" />
                      Facebook
                    </Button>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <Button onClick={shareToLine} className="bg-green-500 hover:bg-green-600 text-white">
                      <MessageCircle className="w-4 h-4 mr-2" />
                      LINE
                    </Button>
                    <Button onClick={shareByEmail} variant="outline" className="border-slate-300">
                      <Mail className="w-4 h-4 mr-2" />
                      メール
                    </Button>
                  </div>

                  <p className="text-sm text-slate-500 text-center mt-4 bg-slate-50 p-3 rounded-lg">
                    💡 共有すると、警報画像の設定情報も一緒に送信されます
                  </p>
                </div>
              </DialogContent>
            </Dialog>
          </div>

          {/* プレビュー */}
          <div className="xl:col-span-2">
            <Card className="border-0 shadow-2xl bg-white/90 backdrop-blur-sm">
              <CardHeader className="bg-gradient-to-r from-slate-50 to-slate-100 rounded-t-lg">
                <CardTitle className="text-slate-800 text-xl">リアルタイムプレビュー</CardTitle>
                <CardDescription>作成される警報画像のプレビューです（横向きB4サイズ）</CardDescription>
              </CardHeader>
              <CardContent className="p-6">
                <div className="border-2 border-slate-200 rounded-xl overflow-hidden bg-white shadow-inner">
                  <canvas ref={canvasRef} className="w-full h-auto max-w-full" style={{ aspectRatio: "2060/1456" }} />
                </div>
                <div className="mt-4 flex items-center justify-between text-sm text-slate-500">
                  <span>解像度: 2060 × 1456px</span>
                  <span>形式: PNG (高品質)</span>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
